package br.com.fiap.primeiro.projeto;

public class Pessoa {

	String nome;
	
	int idade;
	
	
	
}
