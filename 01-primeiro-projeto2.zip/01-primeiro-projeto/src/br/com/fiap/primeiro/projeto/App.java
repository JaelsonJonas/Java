package br.com.fiap.primeiro.projeto;

public class App {

	//M�todo que inicia a execu��o do programa
	public static void main(String[] args) {
		System.out.print("Ol� Devs!");
	}
	
}