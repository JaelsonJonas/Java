package br.com.fiap.primeiro.projeto;

public class Produto {
	
	//Atributos
	String nome;
	
	int quantidade = 1;
	
	long id;
	
	double preco, frete;
	
	float peso;
	
	boolean disponivel = true;
	
	char dimensao;

}