package br.com.fiap.exercicio.classe;

public class Elevador {
	
	//Atributos
	
	int andarAtual;
	
	int totalAndar;
	
	int capacidadeTotal;
	
	int capacidadeAtual;
	
	//Metodos
	
	void inicializa(int andares, int capacidade) {
		totalAndar = andares;
		capacidadeTotal = capacidade;

	}
		
	void subir() {
		andarAtual++;	
	}
	
	void descer() {
		andarAtual--;	
	}

	void entra() {
		capacidadeAtual++;	
	}
	
	void sair() {
		capacidadeAtual--;	
	}
}
