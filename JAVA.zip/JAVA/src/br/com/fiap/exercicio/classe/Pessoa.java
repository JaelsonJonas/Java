package br.com.fiap.exercicio.classe;

public class Pessoa {

	//Atributos
	String nome;
	
	int idade;
	
	float altura;
	
	//M�todos
	
	void alterarNome(String novoNome){
		
		nome = novoNome;
		
	}
	
	void alterarIdade(int novaIdade) {
		
		idade = novaIdade;
	}
	
	void alterarAltura(float novaAltura) {
		altura = novaAltura;
	}
	
	
	String recuperarNome() {
		
		return nome;
	
	}
	
	int recuperarIdade() {
		
		return idade;
	}
	
	
	
	float recuperarAltura() {
		
		return altura;
	}
	
	
}
