package br.com.fiap.exercicio.classe;

// importando o atributo de leitura de dados do JRE
import java.util.Scanner;


public class Leitura {
	
	public static void main(String[] args) {
	

		// criando o metodo "leitor" para coletar a entrada de dados via teclado
		Scanner leitor = new Scanner(System.in);
		
		//realizando o input do valor1
		System.out.println("Digite o valor1:");
	    int valor1 = leitor.nextInt();
		
		
		//exibindo os dados na tela referente ao valor1
		//System.out.println(" o valor1 �:" + valor1);

		//realizando o input dos dados do valor2
		System.out.println("Digite o valor2:");
		int valor2 = leitor.nextInt();
				
					
		//exibindo os dados na tela referente ao valor2
		//System.out.println("O valor2 �:" + valor2);

		
		System.out.println("digite a opera��o a ser realizada (+,-,*,/):");
		String operacao = leitor.next();
		
		Calculadora calc = new Calculadora();
		
		//if ((!operacao.equals("+"))||(!operacao.equals("-"))||(!operacao.equals("*"))||(!operacao.equals("/"))) {
			//System.out.println("Digite um operador valido.");
		
		 if (operacao.equals("+")) {
			
			calc.soma(valor1, valor2);	
			
		} else if (operacao.equals("-")) {
			
			calc.subtracao(valor1, valor2);
			
		}else if (operacao.equals("*")) {
			
			calc.produto(valor1, valor2);
			
		}else if (operacao.equals("/")) {
			
			calc.divisao(valor1, valor2);
			
		} else {
			
			System.out.println("operador invalido!");
		
		}
	
		 
		 System.out.println("Fim");
	
		 
		 
		 
		 
		 
		 
		 leitor.close();
		 
		
	}
	
	
		//int soma(int valor1,int valor2) {
		
		//int resultado = valor1 +valor2;
		
		//return resultado;
		
		//}
		
	
}
